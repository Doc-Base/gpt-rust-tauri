# Examples in `std`

This section contains a few examples of using closures from the `std` library.