# <span style="font-size: 150%">The Rust Performance Book</span>

**<span style="font-size: 130%">First published in November 2020</span>**

**<span style="font-size: 130%">Written by Nicholas Nethercote and others</span>**

[Source code](https://github.com/nnethercote/perf-book)
