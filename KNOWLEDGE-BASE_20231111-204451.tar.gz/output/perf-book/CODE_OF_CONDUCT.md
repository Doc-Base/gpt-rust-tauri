# The Rust Performance Book Code of Conduct

This repository uses the [Rust Code of Conduct].

[Rust Code of Conduct]: https://www.rust-lang.org/conduct.html
