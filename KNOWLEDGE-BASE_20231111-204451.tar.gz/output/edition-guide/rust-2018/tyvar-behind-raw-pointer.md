# Method dispatch for raw pointers to inference variables

## Summary

- The [`tyvar_behind_raw_pointer`][#46906] lint is now a hard error.

[#46906]: https://github.com/rust-lang/rust/issues/46906

## Details

See Rust issue [#46906] for details.