# Acknowledgments

We would like to thank everyone who has worked on the Rust language for
creating an amazing language worth writing a book about. We’re grateful to
everyone in the Rust community for being welcoming and creating an environment
worth welcoming more folks into.

We’re especially thankful for everyone who read early versions of this book
online and provided feedback, bug reports, and pull requests. Special thanks to
Eduard-Mihai Burtescu, Alex Crichton, and JT for providing technical review and
Karen Rustad Tölva for the cover art. Thank you to our team at No Starch,
including Bill Pollock, Liz Chadwick, and Janelle Ludowise, for improving this
book and bringing it to print.

Carol is grateful for the opportunity to work on this book. She thanks her
family for their constant love and support, especially her husband Jake
Goulding and her daughter Vivian.
