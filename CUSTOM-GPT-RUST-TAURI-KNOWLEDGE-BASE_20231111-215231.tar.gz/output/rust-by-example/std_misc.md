# Std misc

Many other types are provided by the std library to support
things such as:

* Threads
* Channels
* File I/O

These expand beyond what the [primitives] provide.

### See also:

[primitives] and [the std library][std]

[primitives]: primitives.md
[std]: https://doc.rust-lang.org/std/
