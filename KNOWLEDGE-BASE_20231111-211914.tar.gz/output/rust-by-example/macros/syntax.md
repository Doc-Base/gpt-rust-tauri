# Syntax

In following subsections, we will show how to define macros in Rust.
There are three basic ideas:

- [Patterns and Designators][designators]
- [Overloading][overloading]
- [Repetition][repetition]

[designators]: designators.md
[overloading]: overload.md
[repetition]: repeat.md
