# About the Authors

Carol Nichols is a member of the Rust Crates.io Team and a former member of the
Rust Core Team. She’s a co-founder of Integer 32, LLC, the world’s first
Rust-focused software consultancy. Nichols has also organized the Rust Belt
Rust Conference.
