# Compatibility

The Rust language is fastly evolving, and because of this certain compatibility
issues can arise, despite efforts to ensure forwards-compatibility wherever
possible.

* [Raw identifiers](compatibility/raw_identifiers.md)
