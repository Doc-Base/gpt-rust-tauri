# Memory model

Rust does not yet have a defined memory model. Various academics and industry professionals
are working on various proposals, but for now, this is an under-defined place
in the language.
